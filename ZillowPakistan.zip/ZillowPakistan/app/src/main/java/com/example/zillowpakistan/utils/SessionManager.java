package com.example.zillowpakistan.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "ZillowSession";
    private static final String KEY_UID = "uid";
    private static final String KEY_DARK_MODE = "dark_mode";

    private final SharedPreferences pref;
    private final SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public void saveLoginSession(String uid) {
        editor.putString(KEY_UID, uid);
        editor.apply();
    }

    public String getUid() {
        return pref.getString(KEY_UID, null);
    }

    public boolean isLoggedIn() {
        return pref.getString(KEY_UID, null) != null;
    }

    public void logout() {
        editor.clear();
        editor.apply();
    }

    public void setDarkModeEnabled(boolean enabled) {
        editor.putBoolean(KEY_DARK_MODE, enabled);
        editor.apply();
    }

    public boolean isDarkModeEnabled() {
        return pref.getBoolean(KEY_DARK_MODE, false);
    }
}
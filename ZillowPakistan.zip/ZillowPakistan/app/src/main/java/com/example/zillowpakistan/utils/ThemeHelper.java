package com.example.zillowpakistan.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.preference.PreferenceManager;

public class ThemeHelper {

    private static final String PREF_DARK_MODE = "dark_mode";

    /**
     * Applies the saved theme preference (dark or light mode).
     */
    public static void applyTheme(boolean darkModeEnabled) {
        AppCompatDelegate.setDefaultNightMode(
                darkModeEnabled
                        ? AppCompatDelegate.MODE_NIGHT_YES
                        : AppCompatDelegate.MODE_NIGHT_NO
        );
    }

    /**
     * Checks if dark mode is enabled by the user preference.
     */
    public static boolean isDarkModeEnabled(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getBoolean(PREF_DARK_MODE, isSystemDarkMode(context));
    }

    /**
     * Saves the user preference for dark mode and applies it immediately.
     */
    public static void setDarkModeEnabled(Context context, boolean enabled) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        prefs.edit().putBoolean(PREF_DARK_MODE, enabled).apply();
        applyTheme(enabled);
    }

    /**
     * Returns true if the system is currently in dark mode.
     */
    public static boolean isSystemDarkMode(Context context) {
        int currentNightMode = context.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK;
        return currentNightMode == Configuration.UI_MODE_NIGHT_YES;
    }
}

package com.example.zillowpakistan.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.zillowpakistan.R;
import com.example.zillowpakistan.activities.PropertyDetailActivity;
import com.example.zillowpakistan.models.Property;

import java.util.List;

public class PropertyAdapter extends RecyclerView.Adapter<PropertyAdapter.PropertyViewHolder> {
    private Context context;
    private List<Property> propertyList;

    public PropertyAdapter(Context context, List<Property> propertyList) {
        this.context = context;
        this.propertyList = propertyList;
    }

    @NonNull
    @Override
    public PropertyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_property, parent, false);
        return new PropertyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PropertyViewHolder holder, int position) {
        Property property = propertyList.get(position);
        holder.tvTitle.setText(property.getTitle());
        holder.tvPrice.setText("$" + property.getPrice());
        holder.tvCity.setText(property.getCity());

        // Load image via Glide
        Glide.with(context)
                .load(property.getImageUrl())
                .placeholder(R.drawable.ic_placeholder)
                .into(holder.ivImage);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, PropertyDetailActivity.class);
            intent.putExtra("propertyId", property.getPropertyId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return propertyList.size();
    }

    public static class PropertyViewHolder extends RecyclerView.ViewHolder {
        ImageView ivImage;
        TextView tvTitle, tvPrice, tvCity;

        public PropertyViewHolder(@NonNull View itemView) {
            super(itemView);
            ivImage = itemView.findViewById(R.id.ivPropertyImage);
            tvTitle = itemView.findViewById(R.id.tvPropertyTitle);
            tvPrice = itemView.findViewById(R.id.tvPropertyPrice);
            tvCity = itemView.findViewById(R.id.tvPropertyCity);
        }
    }
}

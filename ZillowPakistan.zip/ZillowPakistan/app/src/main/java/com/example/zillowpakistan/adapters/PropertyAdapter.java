package com.example.zillowpakistan.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.zillowpakistan.R;
import com.example.zillowpakistan.activities.PropertyDetailActivity;
import com.example.zillowpakistan.databinding.ItemPropertyBinding;
import com.example.zillowpakistan.models.Property;

import java.util.ArrayList;
import java.util.List;

public class PropertyAdapter extends RecyclerView.Adapter<PropertyAdapter.PropertyViewHolder> {
    private final Context context;
    private final List<Property> propertyList = new ArrayList<>();

    public PropertyAdapter(Context context) {
        this.context = context;
    }

    public void setPropertyList(List<Property> list) {
        propertyList.clear();
        if (list != null) {
            propertyList.addAll(list);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public PropertyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPropertyBinding binding = ItemPropertyBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new PropertyViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PropertyViewHolder holder, int position) {
        Property property = propertyList.get(position);
        holder.bind(property);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, PropertyDetailActivity.class);
            intent.putExtra("propertyId", property.getPropertyId());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return propertyList.size();
    }

    static class PropertyViewHolder extends RecyclerView.ViewHolder {
        private final ItemPropertyBinding binding;

        public PropertyViewHolder(ItemPropertyBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        @SuppressLint("SetTextI18n")
        public void bind(Property property) {
            binding.tvPropertyTitle.setText(property.getTitle());
            binding.tvPropertyPrice.setText("Rs " + String.format("%,.0f", property.getPrice()));
            binding.tvPropertyCity.setText(property.getCity());

            Glide.with(binding.getRoot().getContext())
                    .load(property.getImageUrl())
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_user)
                    .into(binding.ivPropertyImage);
        }
    }
}

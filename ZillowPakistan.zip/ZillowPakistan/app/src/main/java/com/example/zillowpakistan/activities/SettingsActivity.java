package com.example.zillowpakistan.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.zillowpakistan.R;
import com.example.zillowpakistan.databinding.ActivitySettingsBinding;
import com.example.zillowpakistan.utils.ThemeHelper;

public class SettingsActivity extends AppCompatActivity {
    private ActivitySettingsBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        boolean darkModeEnabled = ThemeHelper.isDarkModeEnabled(this);
        binding.switchDarkMode.setChecked(darkModeEnabled);

        binding.switchDarkMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            ThemeHelper.setDarkModeEnabled(this, isChecked);
            setResult(RESULT_OK);
        });
    }
}
package com.example.zillowpakistan.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.zillowpakistan.R;
import com.example.zillowpakistan.adapters.PropertyAdapter;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.models.Property;
import com.example.zillowpakistan.utils.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvProperties;
    private PropertyAdapter propertyAdapter;
    private SessionManager sessionManager;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
            return;
        }

        rvProperties = findViewById(R.id.rvProperties);
        rvProperties.setLayoutManager(new LinearLayoutManager(this));

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.nav_home);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.nav_home:
                    // Already here
                    return true;
                case R.id.nav_add:
                    startActivity(new Intent(MainActivity.this, AddPropertyActivity.class));
                    return true;
                case R.id.nav_favorites:
                    startActivity(new Intent(MainActivity.this, FavoritesActivity.class));
                    return true;
                case R.id.nav_profile:
                    startActivity(new Intent(MainActivity.this, ProfileActivity.class));
                    return true;
            }
            return false;
        });

        loadAllProperties();
    }

    private void loadAllProperties() {
        FirebaseHelper.getAllProperties(properties -> {
            if (properties.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        getString(R.string.no_properties_found),
                        Toast.LENGTH_SHORT).show();
            }
            propertyAdapter = new PropertyAdapter(MainActivity.this, properties);
            rvProperties.setAdapter(propertyAdapter);
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                return true;
            case R.id.action_logout:
                FirebaseHelper.logoutUser();
                sessionManager.clearSession();
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

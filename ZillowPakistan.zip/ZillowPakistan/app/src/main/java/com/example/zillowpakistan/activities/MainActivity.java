package com.example.zillowpakistan.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;

import com.example.zillowpakistan.R;
import com.example.zillowpakistan.adapters.PropertyAdapter;
import com.example.zillowpakistan.databinding.ActivityMainBinding;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.models.Property;
import com.example.zillowpakistan.utils.SessionManager;
import com.example.zillowpakistan.utils.ThemeHelper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private PropertyAdapter propertyAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SessionManager sessionManager = new SessionManager(this);
        if (FirebaseAuth.getInstance().getCurrentUser() == null || !sessionManager.isLoggedIn()) {
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return;
        }

        ThemeHelper.applyTheme(ThemeHelper.isDarkModeEnabled(this));
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupToolbar();
        setupBottomNavigation();
        setupRecyclerView();
        setupFab();
    }

    private void setupToolbar() {
        setSupportActionBar(binding.toolbar);
        binding.toolbar.setTitle(R.string.app_name);
    }

    private void setupBottomNavigation() {
        binding.bottomNavigationView.setSelectedItemId(R.id.nav_home);
        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                return true;
            } else if (itemId == R.id.abAdd) {
                startActivity(new Intent(this, AddPropertyActivity.class));
                return true;
            } else if (itemId == R.id.nav_favorites) {
                startActivity(new Intent(this, FavoritesActivity.class));
                return true;
            } else if (itemId == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                return true;
            }
            return false;
        });
    }

    private void setupRecyclerView() {
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        propertyAdapter = new PropertyAdapter(this);
        binding.recyclerView.setAdapter(propertyAdapter);
    }

    private void setupFab() {
        binding.fabAdd.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AddPropertyActivity.class))
        );
    }

    private void loadProperties() {
        binding.progressBar.setVisibility(View.VISIBLE);

        FirebaseHelper.getPropertiesQuery().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Property> list = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    Property property = child.getValue(Property.class);
                    if (property != null) {
                        property.setPropertyId(child.getKey());
                        list.add(property);
                    }
                }

                propertyAdapter.setPropertyList(list);
                binding.progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Error loading properties", Toast.LENGTH_SHORT).show();
                binding.progressBar.setVisibility(View.GONE);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProperties();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(R.attr.menuTextColor, typedValue, true);
        int menuTextColor = ContextCompat.getColor(this, typedValue.resourceId);

        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            SpannableString span = new SpannableString(item.getTitle());
            span.setSpan(new ForegroundColorSpan(menuTextColor), 0, span.length(), 0);
            item.setTitle(span);
        }

        menu.findItem(R.id.action_dark_mode).setChecked(
                ThemeHelper.isDarkModeEnabled(this)
        );

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        } else if (itemId == R.id.action_dark_mode) {
            boolean newState = !item.isChecked();
            item.setChecked(newState);
            ThemeHelper.setDarkModeEnabled(this, newState);
            recreate();
            return true;
        } else if (itemId == R.id.action_logout) {
            FirebaseAuth.getInstance().signOut();
            SessionManager sessionManager = new SessionManager(this);
            sessionManager.logout();

            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

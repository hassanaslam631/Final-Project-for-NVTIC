package com.example.zillowpakistan.activities;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.zillowpakistan.R;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.models.Property;
import com.example.zillowpakistan.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;
import com.google.firebase.auth.FirebaseUser;

import de.hdodenhof.circleimageview.CircleImageView;

public class PropertyDetailActivity extends AppCompatActivity {
    private CircleImageView ivDetailImage;
    private MaterialTextView tvDetailTitle, tvDetailPrice, tvDetailCity, tvDetailAddress,
            tvDetailDescription, tvDetailSize, tvDetailType;
    private MaterialButton btnFavoriteToggle;
    private SessionManager sessionManager;
    private FirebaseUser currentUser;
    private String propertyId;
    private boolean isFavorited = false;
    private Property currentProperty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_property_detail);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }
        currentUser = FirebaseHelper.getCurrentUser();

        ivDetailImage = findViewById(R.id.ivDetailImage);
        tvDetailTitle = findViewById(R.id.tvDetailTitle);
        tvDetailPrice = findViewById(R.id.tvDetailPrice);
        tvDetailCity = findViewById(R.id.tvDetailCity);
        tvDetailAddress = findViewById(R.id.tvDetailAddress);
        tvDetailDescription = findViewById(R.id.tvDetailDescription);
        tvDetailSize = findViewById(R.id.tvDetailSize);
        tvDetailType = findViewById(R.id.tvDetailType);
        btnFavoriteToggle = findViewById(R.id.btnFavoriteToggle);

        propertyId = getIntent().getStringExtra("propertyId");
        if (propertyId == null) {
            Toast.makeText(this, "No property data", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadPropertyDetails();
        btnFavoriteToggle.setOnClickListener(v -> toggleFavorite());
    }

    private void loadPropertyDetails() {
        FirebaseHelper.getPropertyById(propertyId, property -> {
            if (property == null) {
                Toast.makeText(PropertyDetailActivity.this, "Property not found", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            currentProperty = property;
            tvDetailTitle.setText(property.getTitle());
            tvDetailPrice.setText("$" + property.getPrice());
            tvDetailCity.setText(property.getCity());
            tvDetailAddress.setText(property.getAddress());
            tvDetailDescription.setText(property.getDescription());
            tvDetailSize.setText("Size: " + property.getSize() + " sqft");
            tvDetailType.setText("Type: " + property.getType());

            Glide.with(PropertyDetailActivity.this)
                    .load(property.getImageUrl())
                    .placeholder(R.drawable.ic_placeholder)
                    .into(ivDetailImage);

            // Check if favorited to set button text
            FirebaseHelper.isPropertyFavorited(currentUser.getUid(), propertyId, isFav -> {
                isFavorited = isFav;
                btnFavoriteToggle.setText(isFavorited ? getString(R.string.unfavorite) : getString(R.string.favorite));
            });
        });
    }

    private void toggleFavorite() {
        if (currentProperty == null) return;

        if (isFavorited) {
            FirebaseHelper.removeFavorite(currentUser.getUid(), propertyId, task -> {
                if (task.isSuccessful()) {
                    isFavorited = false;
                    btnFavoriteToggle.setText(getString(R.string.favorite));
                    Toast.makeText(PropertyDetailActivity.this, "Removed from favorites", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(PropertyDetailActivity.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            FirebaseHelper.addFavorite(currentUser.getUid(), currentProperty, task -> {
                if (task.isSuccessful()) {
                    isFavorited = true;
                    btnFavoriteToggle.setText(getString(R.string.unfavorite));
                    Toast.makeText(PropertyDetailActivity.this, "Added to favorites", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(PropertyDetailActivity.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}

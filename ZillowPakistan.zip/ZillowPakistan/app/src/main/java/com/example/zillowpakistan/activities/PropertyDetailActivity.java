package com.example.zillowpakistan.activities;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.example.zillowpakistan.R;
import com.example.zillowpakistan.databinding.ActivityPropertyDetailBinding;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.models.Property;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseUser;

public class PropertyDetailActivity extends AppCompatActivity {
    private ActivityPropertyDetailBinding binding;
    private String propertyId;
    private boolean isFavorited = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPropertyDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        propertyId = getIntent().getStringExtra("propertyId");
        if (propertyId == null) {
            finish();
            return;
        }

        loadPropertyDetails();
        setupFavoriteButton();
    }

    private void loadPropertyDetails() {
        FirebaseHelper.getPropertyById(propertyId)
                .addOnSuccessListener(dataSnapshot -> {
                    Property property = dataSnapshot.getValue(Property.class);
                    if (property != null) {
                        displayProperty(property);
                        checkFavoriteStatus();
                    }
                })
                .addOnFailureListener(e -> {
                    Snackbar.make(binding.getRoot(), "Failed to load property", Snackbar.LENGTH_LONG).show();
                    finish();
                });
    }

    private void displayProperty(Property property) {
        binding.tvDetailTitle.setText(property.getTitle());
        binding.tvDetailPrice.setText("Rs " + String.format("%,.0f", property.getPrice()));
        binding.tvDetailCity.setText(property.getCity());
        binding.tvDetailAddress.setText(property.getAddress());
        binding.tvDetailDescription.setText(property.getDescription());

        Glide.with(this)
                .load(property.getImageUrl())
                .placeholder(R.drawable.ic_placeholder)
                .into(binding.ivDetailImage);

        // 🔽 Handle Get Directions button
        binding.btnGetDirections.setOnClickListener(v -> openMaps(property.getLatitude(), property.getLongitude(), property.getTitle()));
    }

    private void setupFavoriteButton() {
        binding.btnFavoriteToggle.setOnClickListener(v -> toggleFavorite());
    }

    private void checkFavoriteStatus() {
        FirebaseUser user = FirebaseHelper.getCurrentUser();
        if (user == null) return;

        FirebaseHelper.getUserFavoritesQuery(user.getUid())
                .child(propertyId)
                .get()
                .addOnSuccessListener(dataSnapshot -> {
                    isFavorited = dataSnapshot.exists();
                    updateFavoriteButton();
                });
    }

    private void toggleFavorite() {
        FirebaseUser user = FirebaseHelper.getCurrentUser();
        if (user == null) return;

        binding.progressBar.setVisibility(View.VISIBLE);

        if (isFavorited) {
            FirebaseHelper.removeFavorite(user.getUid(), propertyId)
                    .addOnCompleteListener(this::handleFavoriteResult);
        } else {
            FirebaseHelper.addFavorite(user.getUid(), propertyId)
                    .addOnCompleteListener(this::handleFavoriteResult);
        }
    }

    private void handleFavoriteResult(Task<Void> task) {
        binding.progressBar.setVisibility(View.GONE);
        if (task.isSuccessful()) {
            isFavorited = !isFavorited;
            updateFavoriteButton();
        } else {
            Snackbar.make(binding.getRoot(), "Operation failed", Snackbar.LENGTH_SHORT).show();
        }
    }

    private void updateFavoriteButton() {
        if (isFavorited) {
            binding.btnFavoriteToggle.setText("Remove from Favorites");
            binding.btnFavoriteToggle.setIconResource(R.drawable.ic_heart_filled);  // ✅ correct solid heart icon
        } else {
            binding.btnFavoriteToggle.setText("Add to Favorites");
            binding.btnFavoriteToggle.setIconResource(R.drawable.ic_heart_outline); // ✅ outline icon
        }
    }
    private void openMaps(double latitude, double longitude, String label) {
        if (latitude == 0 || longitude == 0) {
            Snackbar.make(binding.getRoot(), "Invalid location", Snackbar.LENGTH_SHORT).show();
            return;
        }

        String uri = "geo:" + latitude + "," + longitude + "?q=" + latitude + "," + longitude + "(" + Uri.encode(label) + ")";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        intent.setPackage("com.google.android.apps.maps");

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Snackbar.make(binding.getRoot(), "Google Maps app not found", Snackbar.LENGTH_LONG).show();
        }
    }
}
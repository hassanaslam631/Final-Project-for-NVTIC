package com.example.zillowpakistan.activities;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.zillowpakistan.R;
import com.example.zillowpakistan.adapters.PropertyAdapter;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.models.Property;
import com.example.zillowpakistan.utils.SessionManager;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.List;

public class FavoritesActivity extends AppCompatActivity {
    private RecyclerView rvFavorites;
    private SessionManager sessionManager;
    private MaterialToolbar toolbarFavorites;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        toolbarFavorites = findViewById(R.id.toolbarFavorites);
        toolbarFavorites.setNavigationIcon(R.drawable.ic_arrow_back);
        toolbarFavorites.setNavigationOnClickListener(v -> finish());

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }

        rvFavorites = findViewById(R.id.rvFavorites);
        rvFavorites.setLayoutManager(new LinearLayoutManager(this));

        loadFavorites();
    }

    private void loadFavorites() {
        String uid = sessionManager.getUserId();
        FirebaseHelper.getFavorites(uid, favorites -> {
            if (favorites.isEmpty()) {
                Toast.makeText(FavoritesActivity.this, getString(R.string.no_favorites_found), Toast.LENGTH_SHORT).show();
            }
            PropertyAdapter adapter = new PropertyAdapter(FavoritesActivity.this, favorites);
            rvFavorites.setAdapter(adapter);
        });
    }
}

package com.example.zillowpakistan.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.zillowpakistan.R;
import com.example.zillowpakistan.adapters.PropertyAdapter;
import com.example.zillowpakistan.databinding.ActivityFavoritesBinding;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.models.Property;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FavoritesActivity extends AppCompatActivity {
    private ActivityFavoritesBinding binding;
    private PropertyAdapter adapter;
    private final List<Property> favoriteProperties = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFavoritesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupRecyclerView();
        setupBottomNavigation();
        loadFavorites();
    }

    private void setupRecyclerView() {
        adapter = new PropertyAdapter(this);
        binding.rvFavorites.setLayoutManager(new LinearLayoutManager(this));
        binding.rvFavorites.setAdapter(adapter);
    }

    private void setupBottomNavigation() {
        binding.bottomNavigationView.setSelectedItemId(R.id.nav_favorites); // highlight current tab
        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                return true;
            } else if (itemId == R.id.abAdd) {
                startActivity(new Intent(this, AddPropertyActivity.class));
                return true;
            } else if (itemId == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                return true;
            } else if (itemId == R.id.nav_favorites) {
                return true;
            }
            return false;
        });
    }

    private void loadFavorites() {
        FirebaseUser user = FirebaseHelper.getCurrentUser();
        if (user == null) return;

        binding.progressBar.setVisibility(View.VISIBLE);
        binding.rvFavorites.setVisibility(View.GONE);
        binding.emptyState.setVisibility(View.GONE);

        FirebaseHelper.getUserFavoritesQuery(user.getUid())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        favoriteProperties.clear();

                        if (!snapshot.hasChildren()) {
                            showEmptyState(true);
                            return;
                        }

                        int totalFavorites = (int) snapshot.getChildrenCount();
                        final int[] loadedCount = {0};

                        for (DataSnapshot ds : snapshot.getChildren()) {
                            String propertyId = ds.getKey();
                            if (propertyId != null) {
                                FirebaseHelper.getPropertyById(propertyId)
                                        .addOnSuccessListener(propSnap -> {
                                            Property property = propSnap.getValue(Property.class);
                                            if (property != null) {
                                                property.setPropertyId(propertyId); // ✅ Key fix
                                                favoriteProperties.add(property);
                                            }
                                            loadedCount[0]++;
                                            if (loadedCount[0] == totalFavorites) {
                                                updateUIAfterLoad();
                                            }
                                        })
                                        .addOnFailureListener(e -> {
                                            loadedCount[0]++;
                                            if (loadedCount[0] == totalFavorites) {
                                                updateUIAfterLoad();
                                            }
                                        });
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        binding.progressBar.setVisibility(View.GONE);
                        showEmptyState(true);
                    }
                });
    }

    private void updateUIAfterLoad() {
        binding.progressBar.setVisibility(View.GONE);
        adapter.setPropertyList(favoriteProperties);
        binding.rvFavorites.setVisibility(favoriteProperties.isEmpty() ? View.GONE : View.VISIBLE);
        showEmptyState(favoriteProperties.isEmpty());
    }

    private void showEmptyState(boolean isVisible) {
        binding.emptyState.setVisibility(isVisible ? View.VISIBLE : View.GONE);
    }
}

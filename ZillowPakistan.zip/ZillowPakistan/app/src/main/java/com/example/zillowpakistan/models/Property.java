package com.example.zillowpakistan.models;

public class Property {
    private String propertyId;
    private String title;
    private String price;
    private String city;
    private String address;
    private String imageUrl;
    private String description;
    private String size;   // stored as string (e.g., "1200")
    private String type;   // e.g., "House", "Apartment"

    public Property() {
        // Required no-arg constructor for Firebase
    }

    public Property(String propertyId, String title, String price, String city,
                    String address, String imageUrl, String description,
                    String size, String type) {
        this.propertyId = propertyId;
        this.title = title;
        this.price = price;
        this.city = city;
        this.address = address;
        this.imageUrl = imageUrl;
        this.description = description;
        this.size = size;
        this.type = type;
    }

    public String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

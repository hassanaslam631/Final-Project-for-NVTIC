package com.example.zillowpakistan.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.example.zillowpakistan.databinding.ActivitySignupBinding;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.utils.SessionManager;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseUser;

public class SignupActivity extends AppCompatActivity {
    private ActivitySignupBinding binding;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);
        setupClickListeners();
    }

    private void setupClickListeners() {
        binding.btnSignup.setOnClickListener(v -> attemptSignup());
        binding.tvLogin.setOnClickListener(v -> navigateToLogin());
    }

    private void attemptSignup() {
        String fullName = binding.etFullName.getText().toString().trim();
        String email = binding.etEmail.getText().toString().trim();
        String password = binding.etPassword.getText().toString().trim();

        if (!validateInputs(fullName, email, password)) return;

        binding.progressBar.setVisibility(View.VISIBLE);

        FirebaseHelper.registerUser(fullName, email, password, new FirebaseHelper.AuthCallback() {
            @Override
            public void onSuccess(FirebaseUser user) {
                sessionManager.saveLoginSession(user.getUid());
                navigateToMain();
            }

            @Override
            public void onFailure(Exception e) {
                binding.progressBar.setVisibility(View.GONE);
                showError(e.getMessage());
            }
        });
    }

    private boolean validateInputs(String fullName, String email, String password) {
        if (TextUtils.isEmpty(fullName)) {
            binding.tilFullName.setError("Full name is required");
            return false;
        }
        if (TextUtils.isEmpty(email)) {
            binding.tilEmail.setError("Email is required");
            return false;
        }
        if (TextUtils.isEmpty(password)) {
            binding.tilPassword.setError("Password is required");
            return false;
        }
        if (password.length() < 6) {
            binding.tilPassword.setError("Password must be at least 6 characters");
            return false;
        }
        return true;
    }

    private void navigateToMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private void navigateToLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    private void showError(String message) {
        Snackbar.make(binding.getRoot(), "Signup failed: " + message, Snackbar.LENGTH_LONG).show();
    }
}
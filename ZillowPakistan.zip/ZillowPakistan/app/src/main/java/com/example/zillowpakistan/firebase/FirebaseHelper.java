package com.example.zillowpakistan.firebase;

import androidx.annotation.NonNull;

import com.example.zillowpakistan.models.Property;
import com.example.zillowpakistan.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class FirebaseHelper {
    private static FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private static DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference();

    // --------------------------------------------------------------------------------------------
    // User Authentication & Registration
    // --------------------------------------------------------------------------------------------

    public interface AuthCallback {
        void onSuccess(FirebaseUser user);
        void onFailure(Exception e);
    }

    public static void registerUser(final String fullName, String email, String password, final AuthCallback callback) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser fUser = mAuth.getCurrentUser();
                        if (fUser != null) {
                            // Create a User node in /users/{uid}
                            User newUser = new User(fUser.getUid(), fullName, email);
                            dbRef.child("users").child(fUser.getUid()).setValue(newUser)
                                    .addOnCompleteListener(task1 -> {
                                        if (task1.isSuccessful()) {
                                            callback.onSuccess(fUser);
                                        } else {
                                            callback.onFailure(task1.getException());
                                        }
                                    });
                        }
                    } else {
                        callback.onFailure(task.getException());
                    }
                });
    }

    public static void loginUser(String email, String password, final AuthCallback callback) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(mAuth.getCurrentUser());
                    } else {
                        callback.onFailure(task.getException());
                    }
                });
    }

    public static void logoutUser() {
        mAuth.signOut();
    }

    // --------------------------------------------------------------------------------------------
    // Fetching current user or checking login
    // --------------------------------------------------------------------------------------------

    public static FirebaseUser getCurrentUser() {
        return mAuth.getCurrentUser();
    }

    public static void getUserDetails(String uid, final OnGetUserCallback callback) {
        dbRef.child("users").child(uid)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult().exists()) {
                        User user = task.getResult().getValue(User.class);
                        callback.onUserFetched(user);
                    } else {
                        callback.onUserFetched(null);
                    }
                });
    }

    public interface OnGetUserCallback {
        void onUserFetched(User user);
    }

    // --------------------------------------------------------------------------------------------
    // Property operations
    // --------------------------------------------------------------------------------------------

    public static void addProperty(Property property, final OnCompleteListener<Void> listener) {
        String propertyId = dbRef.child("properties").push().getKey();
        if (propertyId != null) {
            property.setPropertyId(propertyId);
            dbRef.child("properties").child(propertyId).setValue(property)
                    .addOnCompleteListener(listener);
        } else {
            // Should never happen, but handle gracefully
            listener.onComplete(Task.forException(new Exception("Unable to generate property ID")));
        }
    }

    public interface OnGetPropertiesCallback {
        void onPropertiesFetched(List<Property> properties);
    }

    public static void getAllProperties(final OnGetPropertiesCallback callback) {
        dbRef.child("properties")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult().exists()) {
                        List<Property> propertyList = new ArrayList<>();
                        for (DataSnapshot ds : task.getResult().getChildren()) {
                            Property property = ds.getValue(Property.class);
                            if (property != null) {
                                propertyList.add(property);
                            }
                        }
                        callback.onPropertiesFetched(propertyList);
                    } else {
                        callback.onPropertiesFetched(new ArrayList<>());
                    }
                });
    }

    public static void getPropertyById(String propertyId, final OnGetPropertyCallback callback) {
        dbRef.child("properties").child(propertyId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult().exists()) {
                        Property property = task.getResult().getValue(Property.class);
                        callback.onPropertyFetched(property);
                    } else {
                        callback.onPropertyFetched(null);
                    }
                });
    }

    public interface OnGetPropertyCallback {
        void onPropertyFetched(Property property);
    }

    // --------------------------------------------------------------------------------------------
    // Favorite operations
    // --------------------------------------------------------------------------------------------

    public static void addFavorite(String uid, Property property, final OnCompleteListener<Void> listener) {
        dbRef.child("favorites")
                .child(uid)
                .child(property.getPropertyId())
                .setValue(property)
                .addOnCompleteListener(listener);
    }

    public static void removeFavorite(String uid, String propertyId, final OnCompleteListener<Void> listener) {
        dbRef.child("favorites")
                .child(uid)
                .child(propertyId)
                .removeValue()
                .addOnCompleteListener(listener);
    }

    public interface OnGetFavoritesCallback {
        void onFavoritesFetched(List<Property> favorites);
    }

    public static void getFavorites(String uid, final OnGetFavoritesCallback callback) {
        dbRef.child("favorites").child(uid)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult().exists()) {
                        List<Property> favList = new ArrayList<>();
                        for (DataSnapshot ds : task.getResult().getChildren()) {
                            Property property = ds.getValue(Property.class);
                            if (property != null) {
                                favList.add(property);
                            }
                        }
                        callback.onFavoritesFetched(favList);
                    } else {
                        callback.onFavoritesFetched(new ArrayList<>());
                    }
                });
    }

    public static void isPropertyFavorited(String uid, String propertyId, final OnCheckFavoriteCallback callback) {
        dbRef.child("favorites")
                .child(uid)
                .child(propertyId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onCheckResult(task.getResult().exists());
                    } else {
                        callback.onCheckResult(false);
                    }
                });
    }

    public interface OnCheckFavoriteCallback {
        void onCheckResult(boolean isFavorited);
    }
}

package com.example.zillowpakistan.firebase;

import android.net.Uri;

import com.example.zillowpakistan.models.Property;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.UUID;

public class FirebaseHelper {

    // Firebase instances
    private static final FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private static final DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference();
    private static final StorageReference storageRef = FirebaseStorage.getInstance().getReference();

    // ----------------------------
    // 🔐 AUTHENTICATION METHODS
    // ----------------------------

    public interface AuthCallback {
        void onSuccess(FirebaseUser user);
        void onFailure(Exception e);
    }

    public static void registerUser(String fullName, String email, String password, AuthCallback callback) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            dbRef.child("users").child(user.getUid()).child("fullName").setValue(fullName);
                            callback.onSuccess(user);
                        } else {
                            callback.onFailure(new Exception("User is null after registration"));
                        }
                    } else {
                        callback.onFailure(task.getException());
                    }
                });
    }

    public static void loginUser(String email, String password, AuthCallback callback) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            callback.onSuccess(user);
                        } else {
                            callback.onFailure(new Exception("User is null after login"));
                        }
                    } else {
                        callback.onFailure(task.getException());
                    }
                });
    }

    public static void logoutUser() {
        mAuth.signOut();
    }

    public static FirebaseUser getCurrentUser() {
        return mAuth.getCurrentUser();
    }

    // ----------------------------
    // 🏠 PROPERTY METHODS
    // ----------------------------

    public static Task<Void> addProperty(Property property) {
        String propertyId = dbRef.child("properties").push().getKey();
        property.setPropertyId(propertyId);
        property.setCreatedAt(System.currentTimeMillis());
        property.setOwnerUid(getCurrentUser().getUid());
        return dbRef.child("properties").child(propertyId).setValue(property);
    }

    public static Task<DataSnapshot> getPropertyById(String propertyId) {
        return dbRef.child("properties").child(propertyId).get();
    }

    public static Query getPropertiesQuery() {
        return dbRef.child("properties").orderByChild("createdAt");
    }

    // ----------------------------
    // 📷 IMAGE UPLOAD METHODS
    // ----------------------------

    public static UploadTask uploadPropertyImage(Uri imageUri) {
        String filename = "property_" + UUID.randomUUID().toString() + ".jpg";
        return storageRef.child("property_images/" + filename).putFile(imageUri);
    }

    // Optional: if ever needed elsewhere
    public static Task<Uri> getImageDownloadUrl(UploadTask.TaskSnapshot taskSnapshot) {
        return taskSnapshot.getStorage().getDownloadUrl();
    }

    // ----------------------------
    // ❤️ FAVORITES METHODS
    // ----------------------------

    public static Task<Void> addFavorite(String userId, String propertyId) {
        return dbRef.child("favorites").child(userId).child(propertyId).setValue(true);
    }

    public static Task<Void> removeFavorite(String userId, String propertyId) {
        return dbRef.child("favorites").child(userId).child(propertyId).removeValue();
    }

    public static DatabaseReference getUserFavoritesQuery(String userId) {
        return dbRef.child("favorites").child(userId);
    }
}

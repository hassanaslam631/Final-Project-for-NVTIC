package com.example.zillowpakistan.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.zillowpakistan.R;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.models.Property;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AddPropertyActivity extends AppCompatActivity {

    private EditText editTitle, editPrice, editCity, editAddress, editLatitude, editLongitude;
    private Button btnSubmit;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_property);

        editTitle = findViewById(R.id.editTitle);
        editPrice = findViewById(R.id.editPrice);
        editCity = findViewById(R.id.editCity);
        editAddress = findViewById(R.id.editAddress);
        editLatitude = findViewById(R.id.editLatitude);     // ✅ New
        editLongitude = findViewById(R.id.editLongitude);   // ✅ New
        btnSubmit = findViewById(R.id.btnSubmit);
        progressBar = findViewById(R.id.progressBar);

        btnSubmit.setOnClickListener(v -> {
            String title = editTitle.getText().toString().trim();
            String priceStr = editPrice.getText().toString().trim();
            String city = editCity.getText().toString().trim();
            String address = editAddress.getText().toString().trim();
            String latitudeStr = editLatitude.getText().toString().trim();     // ✅ New
            String longitudeStr = editLongitude.getText().toString().trim();   // ✅ New

            if (title.isEmpty() || priceStr.isEmpty() || city.isEmpty() || address.isEmpty()
                    || latitudeStr.isEmpty() || longitudeStr.isEmpty()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
                return;
            }

            double price, latitude, longitude;
            try {
                price = Double.parseDouble(priceStr);
                latitude = Double.parseDouble(latitudeStr);
                longitude = Double.parseDouble(longitudeStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number input", Toast.LENGTH_SHORT).show();
                return;
            }

            Property property = new Property();
            property.setTitle(title);
            property.setPrice(price);
            property.setCity(city);
            property.setAddress(address);
            property.setLatitude(latitude);       // ✅ New
            property.setLongitude(longitude);     // ✅ New
            property.setImageUrl("no_image");

            progressBar.setVisibility(View.VISIBLE);
            FirebaseHelper.addProperty(property)
                    .addOnSuccessListener(unused -> {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(this, "Property added!", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(this, "Failed to add property", Toast.LENGTH_SHORT).show();
                    });
        });

        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);
        bottomNav.setSelectedItemId(R.id.abAdd);

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                return true;
            } else if (id == R.id.nav_favorites) {
                startActivity(new Intent(this, FavoritesActivity.class));
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                return true;
            } else if (id == R.id.abAdd) {
                return true;
            }
            return false;
        });
    }
}

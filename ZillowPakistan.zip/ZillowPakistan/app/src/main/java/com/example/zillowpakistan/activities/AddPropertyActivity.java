package com.example.zillowpakistan.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.zillowpakistan.R;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.models.Property;
import com.example.zillowpakistan.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseUser;

public class AddPropertyActivity extends AppCompatActivity {
    private TextInputEditText etTitle, etPrice, etCity, etAddress, etImageUrl, etDescription, etSize, etType;
    private MaterialButton btnAddProperty;
    private SessionManager sessionManager;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_property);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }
        currentUser = FirebaseHelper.getCurrentUser();

        etTitle = findViewById(R.id.etTitle);
        etPrice = findViewById(R.id.etPrice);
        etCity = findViewById(R.id.etCity);
        etAddress = findViewById(R.id.etAddress);
        etImageUrl = findViewById(R.id.etImageUrl);
        etDescription = findViewById(R.id.etDescription);
        etSize = findViewById(R.id.etSize);
        etType = findViewById(R.id.etType);
        btnAddProperty = findViewById(R.id.btnAddProperty);

        btnAddProperty.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String price = etPrice.getText().toString().trim();
            String city = etCity.getText().toString().trim();
            String address = etAddress.getText().toString().trim();
            String imageUrl = etImageUrl.getText().toString().trim();
            String description = etDescription.getText().toString().trim();
            String size = etSize.getText().toString().trim();
            String type = etType.getText().toString().trim();

            if (TextUtils.isEmpty(title)) {
                etTitle.setError("Title required");
                return;
            }
            if (TextUtils.isEmpty(price)) {
                etPrice.setError("Price required");
                return;
            }
            if (TextUtils.isEmpty(city)) {
                etCity.setError("City required");
                return;
            }
            if (TextUtils.isEmpty(address)) {
                etAddress.setError("Address required");
                return;
            }
            if (TextUtils.isEmpty(imageUrl)) {
                etImageUrl.setError("Image URL required");
                return;
            }
            if (TextUtils.isEmpty(description)) {
                etDescription.setError("Description required");
                return;
            }
            if (TextUtils.isEmpty(size)) {
                etSize.setError("Size required");
                return;
            }
            if (TextUtils.isEmpty(type)) {
                etType.setError("Type required");
                return;
            }

            Property property = new Property();
            // propertyId will be assigned inside addProperty()
            property.setTitle(title);
            property.setPrice(price);
            property.setCity(city);
            property.setAddress(address);
            property.setImageUrl(imageUrl);
            property.setDescription(description);
            property.setSize(size);
            property.setType(type);

            FirebaseHelper.addProperty(property, task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(AddPropertyActivity.this, "Property added", Toast.LENGTH_SHORT).show();
                    finish(); // go back to MainActivity
                } else {
                    Toast.makeText(AddPropertyActivity.this, "Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });
    }
}

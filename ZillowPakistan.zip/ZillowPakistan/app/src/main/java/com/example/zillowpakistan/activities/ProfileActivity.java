package com.example.zillowpakistan.activities;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.zillowpakistan.R;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.models.User;
import com.example.zillowpakistan.utils.SessionManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textview.MaterialTextView;

public class ProfileActivity extends AppCompatActivity {
    private MaterialTextView tvProfileName, tvProfileEmail;
    private MaterialButton btnLogout;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        sessionManager = new SessionManager(this);
        if (!sessionManager.isLoggedIn()) {
            finish();
            return;
        }

        tvProfileName = findViewById(R.id.tvProfileName);
        tvProfileEmail = findViewById(R.id.tvProfileEmail);
        btnLogout = findViewById(R.id.btnLogout);

        loadUserProfile();

        btnLogout.setOnClickListener(v -> {
            FirebaseHelper.logoutUser();
            sessionManager.clearSession();
            finish();
        });
    }

    private void loadUserProfile() {
        String uid = sessionManager.getUserId();
        FirebaseHelper.getUserDetails(uid, user -> {
            if (user != null) {
                tvProfileName.setText(user.getFullName());
                tvProfileEmail.setText(user.getEmail());
            } else {
                Toast.makeText(ProfileActivity.this, "Unable to fetch user data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

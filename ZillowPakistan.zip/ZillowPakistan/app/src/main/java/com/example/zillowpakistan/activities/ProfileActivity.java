package com.example.zillowpakistan.activities;

import android.content.Intent;
import android.os.Bundle;
import android.content.res.Configuration;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.zillowpakistan.R;
import com.example.zillowpakistan.databinding.ActivityProfileBinding;
import com.example.zillowpakistan.firebase.FirebaseHelper;
import com.example.zillowpakistan.utils.ThemeHelper;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ProfileActivity extends AppCompatActivity {
    private ActivityProfileBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // ✅ Apply saved theme first
        ThemeHelper.applyTheme(ThemeHelper.isDarkModeEnabled(this));

        super.onCreate(savedInstanceState);
        binding = ActivityProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        loadUserProfile();
        setupLogoutButton();
        setupBottomNavigation();
        setupDarkModeButton();
    }

    private void loadUserProfile() {
        FirebaseUser user = FirebaseHelper.getCurrentUser();
        if (user == null) {
            finish();
            return;
        }

        binding.tvProfileEmail.setText(user.getEmail());

        if (user.getPhotoUrl() != null) {
            Glide.with(this)
                    .load(user.getPhotoUrl())
                    .circleCrop()
                    .into(binding.ivProfileImage);
        }
    }

    private void setupLogoutButton() {
        binding.btnLogout.setOnClickListener(v -> showLogoutConfirmation());
    }

    private void showLogoutConfirmation() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Logout", (dialog, which) -> logout())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void logout() {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(this, LoginActivity.class));
        finishAffinity();
    }

    private void setupBottomNavigation() {
        binding.bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        binding.bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                return true;
            } else if (id == R.id.abAdd) {
                startActivity(new Intent(this, AddPropertyActivity.class));
                return true;
            } else if (id == R.id.nav_favorites) {
                startActivity(new Intent(this, FavoritesActivity.class));
                return true;
            } else return id == R.id.nav_profile;
        });
    }

    private void setupDarkModeButton() {
        binding.btnToggleDarkMode.setOnClickListener(v -> {
            boolean currentDarkMode = ThemeHelper.isDarkModeEnabled(this);
            ThemeHelper.setDarkModeEnabled(this, !currentDarkMode);
            recreate(); // Refresh to apply theme
        });
    }
}
